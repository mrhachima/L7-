# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'd57c76cf7997c2581cfed4608a3c133f2a25850a7a7407f2ebd4bc52d934d1ad3189302fc2667f81eb0889b19ae21e80b8377b71bdaa24b3fb012b55d018eae0'