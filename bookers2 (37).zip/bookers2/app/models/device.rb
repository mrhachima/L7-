class Device < ApplicationRecord
end
