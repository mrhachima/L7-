class HomesController < ApplicationController
 before_action :authenticate_user!,except: [:top,:about]
 def top
  @user = User.new
 end
 def about
 end
end
